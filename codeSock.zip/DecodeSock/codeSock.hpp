//		Filename >> codeSock.hpp
//		Blog >> https://mawile.tistory.com
//		Developer >> Decode


#include <winsock.h>
#include <iostream>
#include <thread>
#define derror() WSAGetLastError()
using namespace std;

namespace decode{
	int SIZE=1024;
	SOCKET servsock1,*cliensock1;
	SOCKADDR_IN servaddr1,*clienaddr1;
	int *cliensize1;
	int MAXCLIENTS=1;
	char z[20]={0},form[20]={0};
	
	void clientthreadcommandrepeating(){
		char clientmsg[SIZE]={0};
		if(strcmp(form,"mclient")) return;
		while(1){
			recv(servsock1,clientmsg,SIZE,0);
			if(WSAGetLastError()) break;
				cout << "<SERVER> " << clientmsg << endl;
			}
		closesocket(servsock1);
	}
	
	void recvs(SOCKET &s,int catchbug){
		char clientmsg[SIZE]={0};
		while(1){
			recv(s,clientmsg,SIZE,0);
			if(WSAGetLastError()) break;
				cout << "<CLIENT#"<< catchbug << "> " << clientmsg << endl;
			}
		closesocket(s);
	}
	
		void clientaccept(){
			for(int i=0;i<MAXCLIENTS;i++){
				itoa(i,z,10);
				cliensize1[i] = sizeof(clienaddr1[i]);
				cliensock1[i] = accept(servsock1, (SOCKADDR*)&clienaddr1[i],&cliensize1[i]);
				send(cliensock1[i],z,strlen(z),0);
				thread (decode::recvs,ref(cliensock1[i]),i).detach();
				cout << "[+][" << i << "]" << inet_ntoa(clienaddr1[i].sin_addr) << endl;
			}
		}
class tcp{
	private:
		WSADATA wsa;
		SOCKET servsock0,cliensock0;
		SOCKADDR_IN servaddr0={0},clienaddr0={0};
		int cliensize0,intnum;
	public:
		void server(int PORT){
			strcpy(form,"server");
			WSAStartup(MAKEWORD(2,2),&wsa);
			servsock0 = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
			
			servaddr0.sin_family = AF_INET;
			servaddr0.sin_port = htons(PORT);
			servaddr0.sin_addr.s_addr = htonl(INADDR_ANY);
			
			bind(servsock0,(SOCKADDR*)&servaddr0,sizeof(servaddr0));
			listen(servsock0,SOMAXCONN);
			
			cliensize0 = sizeof(clienaddr0);
			cliensock0 = accept(servsock0,(SOCKADDR*)&clienaddr0,&cliensize0);
		}
		void server_m(int PORT,int Clients){
			strcpy(form,"mserver");
			MAXCLIENTS = Clients;
			cliensock1 = new SOCKET[MAXCLIENTS];
			clienaddr1 = new SOCKADDR_IN[MAXCLIENTS];
			cliensize1 = new int[MAXCLIENTS];
			WSAStartup(MAKEWORD(2,2),&wsa);
			servsock1 = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
			
			servaddr1.sin_family = AF_INET;
			servaddr1.sin_port = htons(PORT);
			servaddr1.sin_addr.s_addr = htonl(INADDR_ANY);
			
			bind(servsock1,(SOCKADDR*)&servaddr1,sizeof(servaddr1));
			listen(servsock1,SOMAXCONN);
		}
		void client(const char IP[],int PORT,bool ConnectionLoop){
			strcpy(form,"client");
			WSAStartup(MAKEWORD(2,2),&wsa);
			servsock0 = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
			
			servaddr0.sin_family = AF_INET;
			servaddr0.sin_port = htons(PORT);
			servaddr0.sin_addr.s_addr = inet_addr(IP);
			
			if(!ConnectionLoop) connect(servsock0,(SOCKADDR*)&servaddr0,sizeof(servaddr0));
			else if(ConnectionLoop) while(connect(servsock0,(SOCKADDR*)&servaddr0,sizeof(servaddr0)));
		}
		void client_m(const char IP[],int PORT,bool ConnectionLoop){
			strcpy(form,"mclient");
			WSAStartup(MAKEWORD(2,2),&wsa);
			servsock1 = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
			
			servaddr1.sin_family = AF_INET;
			servaddr1.sin_port = htons(PORT);
			servaddr1.sin_addr.s_addr = inet_addr(IP);
			
			if(!ConnectionLoop) connect(servsock1,(SOCKADDR*)&servaddr1,sizeof(servaddr1));
			else if(ConnectionLoop) while(connect(servsock1,(SOCKADDR*)&servaddr1,sizeof(servaddr1)));
			char charnum[100]={0};
			recv(servsock1,charnum,SIZE,0);
			intnum = atoi(charnum);
		}
		void close(){
			if(!strcmp(form,"server")){
				closesocket(cliensock0);
				closesocket(servsock0);
			}
			else if(!strcmp(form,"client")){
				closesocket(servsock0);
			}
			else if(!strcmp(form,"mserver")){
				int i;
				for(i=0;i<MAXCLIENTS;i++) closesocket(cliensock1[i]);
				delete[] cliensock1;
				delete[] clienaddr1;
				delete[] cliensize1;
				closesocket(servsock1);
			}
			else if(!strcmp(form,"mclient")){
				closesocket(servsock1);
			}
			WSACleanup();
		}
		void sample_thread_server(){
			thread (decode::clientaccept).detach();
		}
		void sample_thread_client(){
			thread (decode::clientthreadcommandrepeating).detach();
		}
		int get_client_number(){ return intnum; }
		void change_packet_size(int size){
			SIZE=size;
		}
		void clear_socket_buffer(){
			u_long i,tmpl;
			char tmpch;
			if(!strcmp(form,"server")){
				ioctlsocket(cliensock0,FIONREAD,&tmpl);
				for(i=0;i<tmpl;i++) recv(cliensock0,&tmpch,sizeof(char),0);
			}
			else if(!strcmp(form,"client")){
				ioctlsocket(servsock0,FIONREAD,&tmpl);
				for(i=0;i<tmpl;i++) recv(servsock0,&tmpch,sizeof(char),0);
			}
			else if(!strcmp(form,"mserver")){
				for(int j=0;j<MAXCLIENTS;j++){
					ioctlsocket(cliensock1[i],FIONREAD,&tmpl);
					for(i=0;i<tmpl;i++) recv(cliensock1[i],&tmpch,sizeof(char),0);
				}
			}
			else if(!strcmp(form,"mclient")){
				ioctlsocket(servsock1,FIONREAD,&tmpl);
				for(i=0;i<tmpl;i++) recv(servsock1,&tmpch,sizeof(char),0);
			}
		}
		int dsend(char *buf){
			int ret;
			if(!strcmp(form,"server")) ret = send(cliensock0,buf,sizeof(buf),0);
			else if(!strcmp(form,"client")) ret = send(servsock0,buf,sizeof(buf),0);
			else return -1;
			return ret;
		}
		int drecv(char *buf){
			int ret;
			if(!strcmp(form,"server")) ret = recv(cliensock0,buf,SIZE,0);
			else if(!strcmp(form,"client")) ret = recv(servsock0,buf,SIZE,0);
			else return -1;
			return ret;
		}
		int dsend_m(char *buf){ //Ŭ���̾�Ʈ���� 
			int ret;
			if(!strcmp(form,"mclient")) ret = send(servsock1,buf,sizeof(buf),0);
			else return -1;
			return ret;
		}
		int dsend_m(char *buf,int ToSend){ //�������� 
			int ret;
			if(!strcmp(form,"mserver")) ret = send(cliensock1[ToSend],buf,sizeof(buf),0);
			else return -1;
			return ret;
		}
		int drecv_m(char *buf){ //Ŭ���̾�Ʈ����
			int ret;
			if(!strcmp(form,"mclient")) ret = recv(servsock1,buf,SIZE,0);
			else return -1;
			return ret;
		}
		int drecv_m(char *buf,int FromReceive){ //�������� 
			int ret;
			if(!strcmp(form,"mserver")) ret = recv(cliensock1[FromReceive],buf,SIZE,0);
			else return -1;
			return ret;
		}
};
}
