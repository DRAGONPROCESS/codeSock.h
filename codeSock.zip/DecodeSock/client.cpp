#include "codeSock.hpp"

int main(){
	decode::tcp tcp;
	tcp.client_m("127.0.0.1",4444,true);
	tcp.change_packet_size(2048);
	
	char buf[decode::SIZE]={0},msg[decode::SIZE]={0};
	tcp.sample_thread_client();
	
	while(1){
		cin>> msg;
		tcp.dsend_m(msg);
	}
	
	tcp.close();
}
