#include "codeSock.hpp"

int main(){
	decode::tcp tcp;
	tcp.server_m(4444,10);
	tcp.change_packet_size(2048);
	
	char buf[decode::SIZE]={0},msg[decode::SIZE]={0};
	tcp.sample_thread_server();
	
	while(1){
		cin >> buf;
		for(int i=0;i<10;i++) tcp.dsend_m(buf,i);
	}
	
	tcp.close();
}
